import React, { useContext, useEffect, useState } from 'react';
import './Registration.css';
import { useNavigate } from 'react-router-dom';
import AppContext from '../AppContext';

export function Registration({ onSuccess, onSwitchToSignIn }) {
  const navigate = useNavigate();
  const { request, backUrl } = useContext(AppContext);

  const [formData, setFormData] = useState({
    FirstName: '',
    LastName: '',
    Email: '',
    WorkingPlace: '',
    Location: '',
    BirthDate: '',
    ProfileImageUrl: null,
    Password: '',
    ConfirmPassword: ''
  });

  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const validate = () => {
    const newErrors = {};

    if (!formData.Email.trim()) {
      newErrors.Email = 'Email or phone is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.Email) && !/^\+?\d{10,}$/.test(formData.Email)) {
      newErrors.Email = 'Enter valid email or phone number';
    }

    if (!formData.FirstName.trim()) newErrors.FirstName = 'First Name is required';
    if (!formData.LastName.trim()) newErrors.LastName = 'Last Name is required';
    if (!formData.Password) newErrors.Password = 'Password is required';
    if (!formData.ConfirmPassword) newErrors.ConfirmPassword = 'Confirm Password is required';
    if (!formData.ProfileImageUrl) newErrors.ProfileImageUrl = 'Profile image is required';

    const passwordRequirements = [
      { test: /.{8,}/, message: 'Password must be at least 8 characters' },
      { test: /[A-Z]/, message: 'Password must contain at least one uppercase letter' },
      { test: /[0-9]/, message: 'Password must contain at least one digit' },
      { test: /[^A-Za-z0-9]/, message: 'Password must contain at least one special character' }
    ];

    for (const req of passwordRequirements) {
      if (!req.test.test(formData.Password)) {
        newErrors.Password = req.message;
        break;
      }
    }

    if (formData.Password !== formData.ConfirmPassword) {
      newErrors.ConfirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = e => {
    const { name, value } = e.target;
    const key = name.charAt(0).toUpperCase() + name.slice(1); 
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleFileChange = e => {
    setFormData(prev => ({ ...prev, ProfileImageUrl: e.target.files[0] }));
  };



  const handleEntrance = () => navigate('/entrance');



  
  const handleSubmit = (e) => {
  e.preventDefault();
  if (!validate()) return;
  const formData = new FormData(e.target);

  fetch(backUrl + "/api/user/registration", {
    method: "POST",
    body: formData
  })
    .then(response => {
      if (!response.ok) {
        return response.text().then(text => {
          throw new Error(text);
        });
      }
      return response.json();
    })
    .then(data => {
      console.log("Status:", data.Status);
      navigate("/verification");
    })
    .catch(err => {
      console.error(err);
      alert(err.message);
    });
};



  return (
    <div className="logo-container1">
      <img src="./Form_img/Logo.png" alt="Logo" className="form-logo1" />
      <div className="form-container">
        <h2 className="welcome-text1">
          Welcome to your<br /><span className="community-text1">professional community</span>
        </h2>
        <form onSubmit={handleSubmit} noValidate>

          <div className="input-group1">
            <input type="text" name="firstName" placeholder="First Name" value={formData.FirstName} onChange={handleChange} />
            {errors.FirstName && <p className="error1">{errors.FirstName}</p>}
          </div>


          <div className="input-group1">
            <input type="text" name="lastName" placeholder="Last Name" value={formData.LastName} onChange={handleChange} />
            {errors.LastName && <p className="error1">{errors.LastName}</p>}
          </div>


          <div className="input-group1">
            <input type="text" name="email" placeholder="Email or phone number" value={formData.Email} onChange={handleChange} />
            {errors.Email && <p className="error1">{errors.Email}</p>}
          </div>


          <div className="input-group1">
            <input type="text" name="workingPlace" placeholder="Working Place" value={formData.WorkingPlace} onChange={handleChange} />
          </div>


          <div className="input-group1">
            <input type="text" name="location" placeholder="Location" value={formData.Location} onChange={handleChange} />
          </div>


          <div className="input-group1">
            <input type="date" name="birthDate" value={formData.BirthDate} onChange={handleChange} />
          </div>


          <div className="input-group1">
            <input type="file" name="profileImageUrl" onChange={handleFileChange} />
            {errors.ProfileImageUrl && <p className="error1">{errors.ProfileImageUrl}</p>}
          </div>


          <div className="input-group1">
            <input type={showPassword ? 'text' : 'password'} name="password" placeholder="Password" value={formData.Password} onChange={handleChange} />
            <span className="icon-right1" onClick={() => setShowPassword(!showPassword)}>
              <img src={showPassword ? "./Form_img/EyeSlash.png" : "./Form_img/eye.png"} alt="toggle visibility" />
            </span>
            {errors.Password && <p className="error1">{errors.Password}</p>}
          </div>

          <div className="input-group1">
            <input type={showConfirm ? 'text' : 'password'} name="confirmPassword" placeholder="Confirm password" value={formData.ConfirmPassword} onChange={handleChange} />
            <span className="icon-right1" onClick={() => setShowConfirm(!showConfirm)}>
              <img src={showConfirm ? "./Form_img/EyeSlash.png" : "./Form_img/eye.png"} alt="toggle visibility" />
            </span>
            {errors.ConfirmPassword && <p className="error1">{errors.ConfirmPassword}</p>}
          </div>

          <button type="submit" className="signup-btn1">Sign Up</button>

          <p className="terms1">
            By Signing Up, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
          </p>

          <div className="divider1"><span>or</span></div>

          <button type="button" className="google-btn1">
            <img src="./Form_img/Google.png" alt="Google Logo" /> Continue with Google
          </button>

          <button type="button" className="signin-btn1" onClick={handleEntrance}>
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}
